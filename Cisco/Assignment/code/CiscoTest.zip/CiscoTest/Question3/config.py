

PG_DATABASE_NAME = 'cisco'
PG_DATABASE_HOST = 'localhost'
PG_DATABASE_PORT = '5432'
PG_DATABASE_USER = 'postgres'
PG_DATABASE_PASSWORD = 'postgres'
